package com.example.fahad_midterm20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class activity2 extends AppCompatActivity {
    RadioButton male = findViewById(R.id.radioButton);
    RadioButton female = findViewById(R.id.radioButton2)
    Button button3 = findViewById(R.id.button);
    Button button4 = findViewById(R.id.button2);
    Button result = findViewById(R.id.result);
    TextView editTextTextPersonName;
    Number editTextNumber;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result.setOnClickListener(new View.OnClickListener()  {
            public void onClick(View v) {

                    if (male.isChecked())
                        result.setText("Hello Mr." + editTextTextPersonName + "you are" + editTextNumber);
                    } else if (female.isChecked()) {

                result.setText("Hello Miss" + editTextTextPersonName + "you are" + editTextNumber);
                    }
                }
            }
         );

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(activity2.this,MainActivity.class);
                startActivity(i);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(activity2.this, activity3.class);
                startActivity(i);
            }
        });
    }


}
