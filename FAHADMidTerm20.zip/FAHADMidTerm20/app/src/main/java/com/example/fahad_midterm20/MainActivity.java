package com.example.fahad_midterm20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {
    ImageView bigImage;
    MediaPlayer mp;
    int song;
    Button button = findViewById(R.id.button);
    Button button2 = findViewById(R.id.button2);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TimerTask task =new TimerTask() {
            @Override
            public void run() {
                finish();
                startActivity(new Intent(MainActivity.this,MainActivity.class));
            }
        };
        Timer t=new Timer();
        t.schedule(task,5000);

        bigImage=findViewById(R.id.imageButton2);

        bigImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mp==null){
                    mp=MediaPlayer.create(MainActivity.this,R.raw.track1);
                    mp.start();
                    song=0;
                    return;
                }
                if (song!=0){
                    mp.stop();
                    mp.release();
                    mp=MediaPlayer.create(MainActivity.this,R.raw.track1);
                    mp.start();
                    song=0;
                    return;
                }
                if (mp.isPlaying()){
                    mp.pause();
                }else{
                    mp.start();
                }


            }

        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(MainActivity.this,activity2.class);
                startActivity(i);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(MainActivity.this, activity3.class);
                startActivity(i);
            }
        });
    }


}